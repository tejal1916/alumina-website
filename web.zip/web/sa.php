<?php
// Start the session
session_start();
?>
<div class="container center-block">
        
                <div class="col-sm-3"></div>
                <div class="col-sm-6">
                     
  
 <form action="" method="POST">
    <div class="form-group">
      <label for="email">Email Address:</label>
      <input type="email" class="form-control" id="email" placeholder="Enter email address" name="email">
    </div>
    <div class="form-group">
      <label for="pwd"> Password:</label>
      <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="pwd">
    </div>
   
    <div>
    
    <button type="submit" class="btn btn-default" name="submit">Submit</button><br>
    <!--<span class="psw">Forgot <a href="#"><a href="forget.php">password?</a></a></span>-->
  </form>
 
</div>
<div class="col-sm-3"></div>

</div>
<?php

   if(isset($_POST['submit']))
{

    echo "email_id: " . $_POST['email'];

    echo "password: " . $_POST['pwd'];

    $x=$_POST['email'];
    $y=$_POST['pwd'];

    $_SESSION['em']=$x;
    $_SESSION['pw']=$y;

}
   
   
   
?>

</body>
</html>
