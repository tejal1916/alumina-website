<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>

<body>
<div class="row" style="background-color: rgb(134, 188, 204)">
        <p><h1 style="text-align-last: center">MGM POLYTECHNIC COLLAGE</h1></p>
    </div>
    <div class="row">
        <nav class="navbar navbar-inverse">
          <div class="container-fluid">
            </ul>
            <ul class="nav navbar-nav" >
                <li class="active"><a href="#">Anumilla website</a></li>
                 </ul>
            <ul class="nav navbar-nav" >
            <li class="active"><a href="home.php">Home</a></li>
             </ul>
             <ul class="nav navbar-nav" >
                <li class="dropdown active"><a class="dropdown-toggle" data-toggle="dropdown" href="#">About us<span class="caret"></span></a>                 <ul class="dropdown-menu">
                   
                      <li><a href="info.php">Information</a></li>
                      <li><a href="intec.php">Intake</a></li>
                      <li><a href="contact.php">Contact us</a></li>
                      </ul></li>  </ul>
                      <ul class="nav navbar-nav" >
                          <li class="active"><a href="event.php">Events</a></li>
                         </ul>
                            <ul class="nav navbar-nav" >
                            <li class="active"><a href="Galery.php">Gallery</a></li>
                           </ul>  
                           <ul class="nav navbar-nav navbar-right" >
                              <li class="active"><a href="sign.php"><span class="glyphicon glyphicon-user">Signup</span></a></li>
                             </ul>            
                             <ul class="nav navbar-nav navbar-right" >
                             <li class="dropdown active"><a class="dropdown-toggle" data-toggle="dropdown" href="#">login<span class="caret"></span></a>                
                              <ul class="dropdown-menu">
                              <li><a href="log.php">USER</a></li>
                      <li><a href="admin.php">ADMIN</a></li>
 
                               </ul></div>
    </nav>
    </div>

       
        <div class="row" style="background-color: rgb(157, 202, 233)">
                <p><h1 style="text-align-last: center">Forget Password</h1></p>
            </div>

            <div class="row" style="background-color: rgb(206,208,211)">
<div class="container center-block">
        <form>
                <div class="col-sm-3"></div>
                <div class="col-sm-6">
                     
  
 <!-- <form action="/action_page.php">-->
    <div class="form-group">
      <label for="email">Email Address:</label>
      <input type="email" class="form-control" id="email" placeholder="Enter email address" name="email">
    </div>
    <div class="form-group">
      <label for="pwd"> New Password:</label>
      <input type="password" class="form-control" id="pwd" placeholder="Enter New password" name="pwd">
    </div>
    
          <div class="form-group">
                <label for="number">  Enter Mobile Number:</label>
                <input type="number" class="form-control" id="number" placeholder="Enter Mobile number" name="contact">
              </div>
    
    <div>
    <button type="reset" class="btn btn-default">Reset</button>
    <button type="submit" class="btn btn-default">Submit</button>
  </form>
 
</div>
<div class="col-sm-3"></div>

</div>


</body>
</html>
