<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>
<div class="row" style="background-color: rgb(134, 188, 204)">
        <p><h1 style="text-align-last: center">MGM POLYTECHNIC COLLAGE</h1></p>
    </div>
    <div class="row">
        <nav class="navbar navbar-inverse">
          <div class="container-fluid">
            </ul>
            <ul class="nav navbar-nav" >
                <li class="active"><a href="#">Anumilla website</a></li>
                 </ul>
            <ul class="nav navbar-nav" >
            <li class="active"><a href="index.php">Home</a></li>
             </ul>
             <ul class="nav navbar-nav" >
                <li class="dropdown active"><a class="dropdown-toggle" data-toggle="dropdown" href="#">About us<span class="caret"></span></a>                 <ul class="dropdown-menu">
                   
                      <li><a href="info.php">Information</a></li>
                      <li><a href="intec.php">Intake</a></li>
                      <li><a href="contact.php">Contact us</a></li>
                      </ul></li>  </ul>
                      <ul class="nav navbar-nav" >
                          <li class="active"><a href="event.php">Events</a></li>
                         </ul>
                            <ul class="nav navbar-nav" >
                            <li class="active"><a href="Galery.php">Gallery</a></li>
                           </ul>  
                           <ul class="nav navbar-nav navbar-right" >
                              <li class="active"><a href="sign.php">Signup</a></li>
                             </ul>            
                             <ul class="nav navbar-nav navbar-right" >
                             <li class="dropdown active"><a class="dropdown-toggle" data-toggle="dropdown" href="#">login<span class="caret"></span></a>                
                              <ul class="dropdown-menu">
                              <li><a href="log.php">USER</a></li>
                      <li><a href="admin.php">ADMIN</a></li>
 
                               </ul></div>
    </nav>
    </div>
    <div class="row" style="background-color:rgb(206,208,211)">

<div class="container">

      <div class="col-sm-4"><img src="z.jpg" width="500" height="300"><br><img src="z1.jpg" width="500" height="300"><img src="z4.jpg" width="500" height="300"><br><img src="z3.jpg" width="500" height="300">>
                                       
     </div>
     <div class="col-sm-4">               </div>
            <div class="col-sm-4" >
            <table class="table table-bordered">
    <thead>
      <tr>
        
        <th>Events</th>
        
      </tr>
    </thead>
    <tbody>
      <tr>
        
     
        <td>    <h4>17-01-2019</h4><br>BLOOD DONATION CAMP ON 20/12/2018 ON TH OCCASION OF 36th MGM FOUNDATION DAY UNDER THE NSS ACTIVITY.</td>
      </tr>
      <tr>
       
        <td>  <h4>17-01-2019</h4><br>MGM's POLYTECHNIC AND BOSCH INDIA JOINT CERTIFICATION TRAINING CENTER INAUGURATED ON 20/12/2018 BY HON. A.N. KADAM AND MS. MAGAZINE SHWETA (HR HEAD)
</td>
      </tr>
      <tr>
       
        <td> <h4>30-11-2018</h4><br>Campus Selection</td>
      </tr>
      <tr>
        <td> <h4>30-11-2018</h4><br>The First Indian Society of Heating, Refrigerating and Air Conditioning Engineers (ISHRAE) Students Chapter in Marathwada Region started by Mechanical Department at MGM's Polytechnic, Aurangabad on 30th July 2018</td>
      </tr>
      <tr>
        <td><h4>12-06-2018</h4><br>
Utkarsh Desarda mechanical student selected as National scholar in Arizona State University in USA
</td>
      </tr>
      <tr>
        <td>        <h4>12-06-2018</h4><br>
 MGM Polytecnic Results 2017-18</td>
</td>
      </tr>
      
      <tr>
        <td>         <h4>17-07-2017</h4><br>
Aadhar Card compulsory for admission from A.Y 2017-18</td>
      </tr>
      
      
    </tbody>
  </table>
</div>

                      </div>
                      
                </div>
  <!--<h2>Bordered Table</h2>
  <p>The .table-bordered class adds borders to a table:</p>   -->         
  
</body>
</html>
