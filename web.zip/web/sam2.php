<html>
<html xmlns="http://www.w3.org/1999/xhtml">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>

<body>

<?php
$link=mysqli_connect("localhost","root","");
mysqli_select_db($link,"register");
?>
<div class="row">
<h2>show</h2>
<?php
		$servername = "localhost";
		$username = "root";
		$password = "";
		$dbname = "alu";
		
		$conn = mysqli_connect($servername, $username, $password, $dbname);
		
		// Check connection
		if (!$conn) {
			die("Connection failed: " . mysqli_connect_error());
        }
        $sql = "select image from register";
        $result = mysqli_query($conn, $sql);
?>
<div class="row">
<div class="col-sm-3"></div>
<div class="col-sm-3">Image</div>
<div class="col-sm-6"></div>
</div>
<?php
if (mysqli_num_rows($result) >0)
{
while($row = mysqli_fetch_assoc($result))
{
    ?>
    <div class="row">

    <div class="3"></div>
    <div class="3"><img src=<?php echo $row["image"]; ?> height="300px" width="200px"></div>
    </div>
<?php
}
}
else{
    echo '<div class="row">';
    echo '<div class=col-sm-12><h2>0 result</h2></div>';
    echo '</div>';
}
mysqli_close($conn);
?>

</div>
</body>
</html>