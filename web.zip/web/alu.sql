-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 13, 2019 at 09:15 AM
-- Server version: 10.1.40-MariaDB
-- PHP Version: 7.3.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `alu`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminlg`
--

CREATE TABLE `adminlg` (
  `Email_id` varchar(100) NOT NULL,
  `Password` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `adminlogin`
--

CREATE TABLE `adminlogin` (
  `Email_id` varchar(100) NOT NULL,
  `Password` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adminlogin`
--

INSERT INTO `adminlogin` (`Email_id`, `Password`) VALUES
('mgm@gmail.com', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `Name` varchar(100) NOT NULL,
  `Contact_no` int(13) NOT NULL,
  `Email_id` varchar(100) NOT NULL,
  `Branch` varchar(30) NOT NULL,
  `Experiance` varchar(25) NOT NULL,
  `Sallery` int(100) NOT NULL,
  `Address` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`Name`, `Contact_no`, `Email_id`, `Branch`, `Experiance`, `Sallery`, `Address`) VALUES
('wipro', 2147483647, 'pooja@gmail.com', 'U.S.A', '7', 1000000000, ''),
('TCS', 2147483647, 'tejalpanmand1234@gmail.com', 'U.S.A', '7', 20000000, 'america'),
('TCS', 2147483647, 'tuhb@gmail.com', 'pune', '6', 34000, 'samahjb kjj'),
('xyx', 2147483647, 'ty@gmail.com', 'me', '7', 67000, 'sara gurav');

-- --------------------------------------------------------

--
-- Table structure for table `enquiry`
--

CREATE TABLE `enquiry` (
  `Name` varchar(100) NOT NULL,
  `Contact_no` int(10) NOT NULL,
  `Email_id` varchar(100) NOT NULL,
  `Age` int(100) NOT NULL,
  `Branch` varchar(25) NOT NULL,
  `Year_name` varchar(10) NOT NULL,
  `Result` int(4) NOT NULL,
  `Address` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `enquiry`
--

INSERT INTO `enquiry` (`Name`, `Contact_no`, `Email_id`, `Age`, `Branch`, `Year_name`, `Result`, `Address`) VALUES
('asfds', 2147483647, 'akshya@gmail.com', 59, 'ej', '1st', 47, 'sara gurav'),
('tejal', 2147483647, 'ans12@gmail.com', 13, 'computerqwq', '3rd', 70, 'sara xcc'),
('rutuja', 2147483647, 'bnbhg@gmail.com', 12, 'computerqwq', '5th', 47, 'sara'),
('cow', 2147483647, 'cow@gmail.com', 56, 'civil', '2nd', 70, 'sara gurav'),
('kavita', 2147483647, 'kavi@gmail.com', 2, 'computer', '1st', 70, 'sara gurav'),
('tejal', 2147483647, 'mgm12@gmail.com', 2, 'me', '1st', 78, 'sara'),
('asfds', 2147483647, 'pooja12@gmail.com', 12, 'civil', '3rd', 47, 'sara'),
('rks', 2147483647, 'rks12@gmail.com', 34, 'civil', '3rd', 78, 'sara gurav'),
('tejal', 2147483647, 'rure@gmail.com', 3, 'computerqwq', '5th', 70, 'sara'),
('tejal panmand', 2147483647, 'rute@gmail.com', 12, 'ej', '1st', 70, 'samahjb kjj'),
('rutuja', 2147483647, 'rutu1232@gmail.com', 45, 'ej', '2nd', 78, 'sara gurav'),
('asfds', 2147483647, 'rutupathare123@gmail.com', 12, 'civil', '2nd', 70, 'sara'),
('tejal', 2147483647, 'rutupathare5678o@gmail.com', 2, 'computerqwq', '5th', 78, 'sara xcc'),
('rutuja', 45678909, 'rutupathare678@gmail.com', 13, 'civil', '1st', 47, 'sara '),
('tejal', 45678909, 'rutupathare89@gmail.com', 3, 'computer', '1st', 78, 'sara xcc'),
('tejal panmand', 2147483647, 'rutupe@gmail.com', 13, 'computerqwq', '5th', 47, 'sara gurav'),
('tejal', 2147483647, 'tejalpanmand1234@gmail.com', 56, 'computer', '5th', 78, 'sara'),
('rutuja', 2147483647, 'tejalpanmand19882@gmail.com', 3, 'me', '1st', 70, 'sara xcc'),
('tejal', 2147483647, 'tever@gmail.com', 6, 'me', '3rd', 78, 'sara gurav'),
('tejal', 2147483647, 'tuhb@gmail.com', 56, 'computer', '1st', 78, 'sara vrundavn'),
('tejal', 2147483647, 'ty123@gmail.com', 3, 'computerqwq', '3rd', 78, 'sara '),
('rutuja', 2147483647, 'ty12@gmail.com', 13, 'me', '1st', 78, 'sara '),
('tejal panmand', 45678909, 'ty567@gmail.com', 12, 'civil', '3rd', 78, 'sara xcc'),
('tejal', 2147483647, 'ty@gmail.com', 13, 'computer', '3rd', 47, 'sara '),
('ryy', 45678909, 'tyu@gmail.com', 12, 'computer', '3rd', 78, 'sara xcc'),
('tejal', 2147483647, 'yz@gmail.com', 56, 'me', '3rd', 78, 'sara xcc');

-- --------------------------------------------------------

--
-- Table structure for table `image`
--

CREATE TABLE `image` (
  `image` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `image`
--

INSERT INTO `image` (`image`) VALUES
('./uploads/Capture.JPG'),
('./uploads/Capture.JPG'),
('./uploads/Capture.JPG');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `Email` varchar(100) NOT NULL,
  `Password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `Name` varchar(100) NOT NULL,
  `Contact_no` int(11) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `Email_id` varchar(100) NOT NULL,
  `Date_of_birth` date NOT NULL,
  `Age` int(11) NOT NULL,
  `Branch_name` varchar(10) NOT NULL,
  `Year_name` varchar(10) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `Image` varchar(5000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`Name`, `Contact_no`, `Password`, `Email_id`, `Date_of_birth`, `Age`, `Branch_name`, `Year_name`, `Address`, `Image`) VALUES
('rutuja ', 2147483647, '1234', 'kkk@gmail.com', '0006-05-31', 7, 'computer', '5th', 'sara xcc', ''),
('you', 2147483647, '1234', 'kky@gmail.com', '2019-05-03', 2019, 'ej', '6th', 'sara xcc', ''),
('rutuja.p', 2147483647, 'www', 'poo@gmail.com', '2000-07-06', 2000, 'civil', '6th', 'sara', ''),
('ritu', 2147483647, 'ritu12', 'ritu@gmail.com', '2012-07-06', 2012, 'computer', 'gffgf', 'sara xcc', ''),
('war', 2147483647, '123456', 'rutupre@gmail.com', '2000-08-07', 2000, 'me', '6th', 'sara ', ''),
('tejal ', 2147483647, 'abc4', 'tuhb5@gmail.com', '0008-07-04', 8, 'computer', '6th', 'sara xcc', ''),
('rutuj ', 789800987, 'abc', 'tuhb@gmail.com', '2020-09-07', 2020, 'computerqw', '5th', 'sara', 'uploads/2018-02-17-13-01-27-173.jpg'),
('panmand', 45678909, 'ccb', 'ty@gmail.com', '2222-02-02', 2222, 'computer', '5th', 'sara xcc', ''),
('rohan', 2147483647, 'wagh12', 'wagh@gmail.com', '2012-05-04', 2012, 'me', '2nd', 'sara vrundavn', ''),
('asfds', 2147483647, '12234', 'www@gmail.com', '2012-08-07', 2012, 'computer', '6th', '', ''),
('xyx', 2147483647, '3456', 'xyx@gmail.com', '2012-08-07', 2012, 'me', '6th', 'sara ', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adminlg`
--
ALTER TABLE `adminlg`
  ADD PRIMARY KEY (`Email_id`);

--
-- Indexes for table `adminlogin`
--
ALTER TABLE `adminlogin`
  ADD PRIMARY KEY (`Email_id`);

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`Email_id`);

--
-- Indexes for table `enquiry`
--
ALTER TABLE `enquiry`
  ADD PRIMARY KEY (`Email_id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`Email`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`Email_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
