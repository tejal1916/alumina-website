<div class="row" style="background-color:rgb(206,208,211)">
        <div class="container_fluid">
        <form action="#" method="POST">
  <div class="col-sm-3"></div>
  <div class="col-sm-6">
    <div class="form-group">
    <label for="name">Name:</label>
    <input type="name" class="form-control" id="name" placeholder="Enter your name" name="name">
    </div>
                    
    <div class="form-group">
    <label for="contact">Contact no:</label>
    <input type="Contact no" class="form-control" id="contact" placeholder="Enter your contact no" name="contact">
    </div>
                
    <div class="form-group">
    <label for="pwdd">Password:</label>
    <input type="password" class="form-control" id="pwdd" placeholder="Enter password" name="pwdd">
    </div>
                      
    <div class="form-group">
      <label for="email">Email Address:</label>
      <input type="email" class="form-control" id="email" placeholder="Enter your email address" name="email">
    </div>

    <div class="form-group">
    <label for="date">Date_of_birth:</label>
    <input type="date" class="form-control" id="date" placeholder="Enter date of birth" name="date">
    </div>

    <div class="form-group">
    <label for="age">Age:</label>
    <input type="age" class="form-control" id="age" placeholder="Enter age" name="age">
    </div>

    <div class="form-group">
    <label for="Branch">Enter Branch name:</label>
    <input type="Branch" class="form-control" id="Branch" placeholder="Enter Branch name" name="Branch">
    </div>

    <div class="form-group">
    <label for="year">Year name:</label>
    <input type="Year" class="form-control" id="Year" placeholder="Enter year name" name="Year">
    </div>
                      
    <div class="form-group">
    <label for="add">Address:</label>
    <input type="address" class="form-control" id="add" placeholder="Enter your address" name="add">
    </div>
    
    <button type="submit" class="btn btn-default" name="btn" value="submit">Submit</button>
     </form> 
    </div>
<div class="col-sm-3"></div>
</div>
</div>
<?php
if(!empty($_POST['name']) && isset($_POST['contact']) && isset($_POST['pwdd']) && isset($_POST['email']) && isset($_POST['date']) && isset($_POST['age']) && isset($_POST['Branch']) && isset($_POST['Year']) && isset($_POST['add']) && isset($_POST['btn']))
{
		$name=$_POST["name"];
		$contact=$_POST["contact"];
		$pwdd=$_POST["pwdd"];
		$email=$_POST["email"];
    $date=$_POST["date"];
    $age=$_POST["age"];
    $Branch=$_POST["Branch"];
    $Year=$_POST["Year"];
    $add=$_POST["add"];
		
		echo "name=" . $name ;
		echo "contact=" . $contact ;
		echo "pwdd=" . $pwdd ;
		echo "email=" . $email ;
    echo "date=" . $date ;
    echo "age=" . $age ;
    echo "Branch=" . $Branch ;
    echo "Year=" . $Year ;
    echo "add=" . $add ;
		$servername = "localhost";
		$username = "root";
		$password = "";
		$dbname = "alu";
		
		$conn = mysqli_connect($servername, $username, $password, $dbname);
		
		// Check connection
    if (!$conn) 
    {
			die("Connection failed: " . mysqli_connect_error());
		}
		//echo "Connected successfully";
		
			$sql = "INSERT INTO register (Name, Contact_no, Password, Email_id, Date_Of_birth, Age, Branch_name, Year_name, Address) VALUES ('$name', '$contact', '$pwdd', '$email', '$date', '$date', '$Branch', '$Year', '$add')";
			
      if (mysqli_query($conn, $sql))
       {
			//	echo "New record created successfully";
			//	header( "Location: log.php" );
      } else
       {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    
      }
      
		mysqli_close($conn);	
}
?>
