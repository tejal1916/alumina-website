<?php
// Start the session
session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>

<body>
<div class="row" style="background-color: rgb(134, 188, 204)">
        <p><h1 style="text-align-last: center">MGM POLYTECHNIC COLLEGE</h1></p>
    </div>
    <div class="row">
        <nav class="navbar navbar-inverse">
          <div class="container-fluid">
            </ul>
            <ul class="nav navbar-nav" >
                <li class="active"><a href="#">Anumilla website</a></li>
                 </ul>
            <ul class="nav navbar-nav" >
            <li class="active"><a href="index.php">Home</a></li>
             </ul>
             <ul class="nav navbar-nav" >
                <li class="dropdown active"><a class="dropdown-toggle" data-toggle="dropdown" href="#">About us<span class="caret"></span></a>                 <ul class="dropdown-menu">
                   
                      <li><a href="info.php">Information</a></li>
                      <li><a href="intec.php">Intake</a></li>
                      <li><a href="contact.php">Contact us</a></li>
                      </ul></li>  </ul>
                      <ul class="nav navbar-nav" >
                          <li class="active"><a href="event.php">Events</a></li>
                         </ul>
                            <ul class="nav navbar-nav" >
                            <li class="active"><a href="Galery.php">Gallery</a></li>
                           </ul>  
                           <ul class="nav navbar-nav navbar-right" >
                              <li class="active"><a href="sign.php">Signup</a></li>
                             </ul>            
                             <ul class="nav navbar-nav navbar-right" >
                             <li class="dropdown active"><a class="dropdown-toggle" data-toggle="dropdown" href="#">login<span class="caret"></span></a>                
                              <ul class="dropdown-menu">
                              <li><a href="log.php">USER</a></li>
                      <li><a href="admin.php">ADMIN</a></li>
 
                               </ul></div>
    </nav>
    </div>

        <div class="row" style="background-color: rgb(157, 202, 233)">
                <p><h1 style="text-align-last: center"> USER LOGIN </h1></p>
            </div>

            <div class="row" style="background-color: rgb(206,208,211)">
<div class="container center-block">
        
                <div class="col-sm-3"></div>
                <div class="col-sm-6">
                     
  
 <form action="" method="POST">
    <div class="form-group">
      <label for="email">Email Address:</label>
      <input type="email" class="form-control" id="email" placeholder="Enter email address" name="email">
    </div>
    <div class="form-group">
      <label for="pwd"> Password:</label>
      <input type="password" class="form-control" id="pwd" placeholder="Enter  password" name="pwd">
    </div>
   
    <div>
    
    <button type="submit" class="btn btn-default">Submit</button><br>
    <span class="psw">Forgot <a href="#"><a href="forget.php">password?</a></a></span>
  </form>
 
</div>
<div class="col-sm-3"></div>

</div>
<?php


if(!empty($_POST['email']) && isset($_POST['pwd']))
{
  $email=$_POST["email"];
  $pwd=$_POST["pwd"];
  
  
  
  
 
  $servername = "localhost";
  $username = "root";
  $password = "";
  
  $dbname = "alu";
  
 /* $servername = "localhost";
  $username = "id10482724_tejal";
  $password = "90115854";
  
  $dbname = "id10482724_alu";*/

  

  
  
  
  $conn = mysqli_connect($servername, $username, $password,$dbname);
  
  // Check connection
  
  
  
  if (!$conn)
   {
    die("Connection failed: " . mysqli_connect_error());
  }
  //echo "Connected successfully";
  
    $sql = "Select * from  register where  Email_id= '$email' and  Password= '$pwd'";
    $result=mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) 
    { 
      $_SESSION["uniqueid"] = $email;
      $_SESSION["password"] = $pwd;
      //echo "New record created successfully"
      header( "Location: welcome.php" );
    } 
    
    else 
    
    {
      
      $message = "wrong emailid or password...please login with valid email and password";
      ?>
     <div class="row">
      <div class="col-sm-3"></div>
      <div class="col-sm-6">
      <h5 style=color:red> invalid password or email id<h5></div>
      <div class="col-sm-3"></div>
      </div> 
     <!-- <script type="text/javascript">alert("first register");
   </script>--->
              
  <?php
     //header( "Location: log.php" );
    
    
  }

   
  mysqli_close($conn);		
}
?>





</body>
</html>
