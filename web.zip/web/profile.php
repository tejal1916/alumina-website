
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Allumina website</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>
<div class="row" style="background-color: rgb(134, 188, 204)">
                <p><h1 style="text-align-last: center">MGM POLYTECHNIC COLLAGE</h1></p>
            </div>
            

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header, active">
      <a class="navbar-brand" href="#"> Allumina WebSite</a>
    </div>
    
    <ul class="nav navbar-nav" >
            <li class="active"><a href="enquiry2.php">Student details</a></li>
             </ul>
             <ul class="nav navbar-nav" >
            <li class="active"><a href="companydetail.php">Comapany details</a></li>
             </ul>
             <ul class="nav navbar-nav">
    <li class="active"><a href="profile.php"><span class="glyphicon glyphicon-user">Profile</span></a></li>
         </ul>
    <form class="navbar-form navbar-right"> 
    <ul class="nav navbar-nav">
    <li class="active"><a href="logoutuser.php"><span class="glyphicon glyphicon-log-in">logout</span></a></li>

     
    </ul></form>
      </div>
</nav>

<form action="upload.php" method="post" enctype="multipart/form-data">
    Select image to upload:
    <input type="file" name="fileToUpload" id="fileToUpload">
    <input type="submit" value="Upload Image" name="submit">


<div class="row" style="background-color: gray">
<div class="row"><h2 style="text-align: center">PERSONAL DETAILS</h2></div>
<div class="row" style="text-align: center">

<?php  
  session_start();
  		$email=$_SESSION["uniqueid"];
		$pwd=$_SESSION["password"];
		
		
				
	$servername = "localhost";
		$username = "root";
		$password = "";
		
    $dbname = "alu";
   
		
		
		
		
		$conn = mysqli_connect($servername, $username, $password,$dbname);
		
		// Check connection
		
		
		
    if (!$conn) 
    {
			die("Connection failed: " . mysqli_connect_error());
		}
		//echo "Connected successfully";
		
			$sql = "Select * from  register where  Email_id= '$email' and  Password= '$pwd'";
			$result=mysqli_query($conn, $sql);
			if (mysqli_num_rows($result) > 0) 
			{
		
				 while($row = $result->fetch_assoc()) {
			
//        echo "<b><i><br> Email_address: </i></b>". $row["Email_address"]. "<b><i><br>Password: </i></b>". $row["Password"]. "<b><i><br>Name:</i></b>" . $row["Name"] . "<b><i><br>Address:</i></b> ". $row["Address"]. "<b><i><br>Contact_no: </i></b>". $row["Contact_no"]. "<br>";
			
echo '<div class="row">';
echo '<div class="col-sm-3"></div><div class="col-sm-6"><label><img src='.$row["Image"].' height=200px width=200px></label></div><div class="col-sm-3"></div>';
echo '</div>';

			echo '<div class="row">';
			echo '<div class="col-sm-3"></div><div class="col-sm-6"><label>Name = </label><label>'.$row["Name"].'</label></div><div class="col-sm-3"></div>';
			echo '</div>';
			
			echo '<div class="row">';
			echo '<div class="col-sm-3"></div><div class="col-sm-6"><label>Contact_no = </label><label>'.$row["Contact_no"].'</label></div><div class="col-sm-3"></div>';
			echo '</div>';
			
			
			echo '<div class="row">';
			echo '<div class="col-sm-3"></div><div class="col-sm-6"><label>Email_id = </label><label>'.$row["Email_id"].'</label></div><div class="col-sm-3"></div>';
			echo '</div>';
			
      echo '<div class="row">';
			echo '<div class="col-sm-3"></div><div class="col-sm-6"><label>Date_of_birth = </label><label>'.$row["Date_of_birth"].'</label></div><div class="col-sm-3"></div>';
			echo '</div>';
			

      echo '<div class="row">';
			echo '<div class="col-sm-3"></div><div class="col-sm-6"><label>Age = </label><label>'.$row["Age"].'</label></div><div class="col-sm-3"></div>';
			echo '</div>';
			

      echo '<div class="row">';
			echo '<div class="col-sm-3"></div><div class="col-sm-6"><label>Branch_name</label><label>'.$row["Branch_name"].'</label></div><div class="col-sm-3"></div>';
			echo '</div>';
			
				
      echo '<div class="row">';
			echo '<div class="col-sm-3"></div><div class="col-sm-6"><label> Year Name = </label><label>'.$row["Year_name"].'</label></div><div class="col-sm-3"></div>';
      echo '</div>';
       
      echo '<div class="row">';
			echo '<div class="col-sm-3"></div><div class="col-sm-6"><label>Address = </label><label>'.$row["Address"].'</label></div><div class="col-sm-3"></div>';
			echo '</div>';
			
			/*
      echo '<div class="row">';
			echo '<div class="col-sm-3"></div><div class="col-sm-6"><label>Image = </label><label><img src='.$row["Image"].' height=200px width=200px></label></div><div class="col-sm-3"></div>';
			echo '</div>';*/
			
			
				
				 }
			} else {
				$message = "please register your name";
			
				?>
                
				<script type="text/javascript">alert("wrong emailid or password...please login with valid email and password");</script>
                <?php
				header( "Location: log.php" );
				
      }?>
</div>
      <div class="row" style="text-align: center">
      <h2>STUDENT DETAILS</h2>
      </div>
      <div class="row">
      <?php
      
			$sql = "Select * from  enquiry where  Email_id= '$email'";
			
		$result = mysqli_query($conn, $sql);
?>
                				
                			



<?php
if (mysqli_num_rows($result) > 0) 
{
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) 
    {
		
?>
				
        <div class="row" style="text-align: center"><label>Name = <?php echo $row["Name"]; ?></label></div>
        <div class="row" style="text-align: center"><label>contact = </label><label><?php echo $row["Contact_no"]; ?></label></div>
        <div class="row" style="text-align: center"><label>Email_id = </label><label><?php echo $row["Email_id"]; ?></label></div>
        <div class="row" style="text-align: center"><label>Age = </label><label><?php echo $row["Age"]; ?></label></div>
        <div class="row" style="text-align: center"><label>Branch = </label><label><?php echo $row["Branch"]; ?></label></div>
        <div class="row" style="text-align: center"><label>Year-name = </label><label><?php echo $row["Year_name"]; ?></label></div>
        <div class="row" style="text-align: center"><label>Reults = </label><label><?php echo $row["Result"]; ?></label></div>
        <div class="row" style="text-align: center"><label>Address = </label><label><?php echo $row["Address"]; ?></label></div>
                    	
<?php
    }
} 
else 
{
    echo '<div class="row">';
    echo '<div class="col-sm-12"></div>';
	echo '</div>';
}
		
	///	mysqli_close($conn);
?></div>
<div class="row" style="text-align: center">
      <h2><br>COMPANY DETAILS</h2>
      </div>
      <?php
      
			$sql = "Select * from company where  Email_id= '$email'";
			
		$result = mysqli_query($conn, $sql);
?>
                				
                			



<?php
if (mysqli_num_rows($result) > 0) 
{
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) 
    {
		
?>
					  <div class="row" style="text-align: center;"><label>Name = </label><label><?php echo $row["Name"]; ?></label></div>
			    	<div class="row" style="text-align: center;"><label>contact = </label><label><?php echo $row["Contact_no"]; ?></label></div>
            <div class="row" style="text-align: center;"><label>Email id = </label><label><?php echo $row["Email_id"]; ?></label></div>
            <div class="row" style="text-align: center;"><label>Age = </label><label><?php echo $row["Branch"]; ?></label></div>
            <div class="row" style="text-align: center;"><label>Branch = </label><label><?php echo $row["Experiance"]; ?></label></div>
            <div class="row" style="text-align: center;"><label>Year-name = </label><label><?php echo $row["Sallery"]; ?></label></div>
            <div class="row" style="text-align: center;"><label>Address = </label><label><?php echo $row["Address"]; ?></label></div>
                    	
<?php
    }
} 

		
		mysqli_close($conn);
?>

</div>

  </div>

</body>
</html>

