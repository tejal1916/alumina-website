<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "alu";

  
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) 
{
    die("Connection failed: " . mysqli_connect_error());
}
else
{
    echo "connected";
}
$email=$_GET['email'];
    $sql = "DELETE FROM register WHERE Email_id='$email'";

		
        if (mysqli_query($conn, $sql))
        {
				echo "<script> alert('Record Deleted successfully') </script>";
				header( "Location: alumina.php" );
        } 
        else
        {
				echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		
	
		
		mysqli_close($conn);
		
		


?>
</body>
</html>