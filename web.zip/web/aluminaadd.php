<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<div class="row" style="background-color: rgb(134, 188, 204)">
                <p><h1 style="text-align-last: center">MGM POLYTECHNIC COLLAGE</h1></p>
            </div>
            

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header, active">
      <a class="navbar-brand" href="#"> Allumina WebSite</a>
    </div>
    <ul class="nav navbar-nav">
    <li class="active"><a href="profilead.php">Profile</a></li>
      <li class="active"><a href="alumina.php">Allumina</a></li>
          </ul>
    <form class="navbar-form navbar-right"> 
    <ul class="nav navbar-nav">
    <li class="active"><a href="adminlogout.php"><span class="glyphicon glyphicon-log-in">logout</span></a></li>

     </ul></form>
   
  </div>
  
</nav>
<div class="row" style="background-color:rgb(206,208,211)">
        <div class="container">
        <form action="#" method="POST">
  <div class="col-sm-3"></div>
  <div class="col-sm-6">
           <h2>Add</h2>
    <div class="form-group">
    <label for="name">Name:</label>
    <input type="name" class="form-control" id="name" placeholder="Enter your name" name="name">
    </div>
                    
    <div class="form-group">
    <label for="contact">Contact no:</label>
    <input type="Contact no" class="form-control" id="contact" placeholder="Enter your contact no" name="contact">
    </div>
                
    <div class="form-group">
    <label for="pwdd">Password:</label>
    <input type="password" class="form-control" id="pwdd" placeholder="Enter password" name="pwdd">
    </div>
                      
    <div class="form-group">
      <label for="email">Email Address:</label>
      <input type="email" class="form-control" id="email" placeholder="Enter your email address" name="email">
    </div>

    <div class="form-group">
    <label for="date">Date_of_birth:</label>
    <input type="date" class="form-control" id="date" placeholder="Enter date of birth" name="date">
    </div>

    <div class="form-group">
    <label for="age">Age:</label>
    <input type="age" class="form-control" id="age" placeholder="Enter age" name="age">
    </div>

    <div class="form-group">
    <label for="Branch">Enter Branch name:</label>
    <input type="Branch" class="form-control" id="Branch" placeholder="Enter Branch name" name="Branch">
    </div>

    <div class="form-group">
    <label for="year">Year name:</label>
    <input type="Year" class="form-control" id="Year" placeholder="Enter year name" name="Year">
    </div>
                      
    <div class="form-group">
    <label for="add">Address:</label>
    <input type="address" class="form-control" id="add" placeholder="Enter your address" name="add">
    </div>
    
    <button type="insert" class="btn btn-default" name="btn" value="add">Add</button>

</form> 
    </div>
<div class="col-sm-3"></div>
</div>
</div>


<?php
if(isset($_POST['btn']))
{
    
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "alu";
 
    // Create connection
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    // Check connection
    if (!$conn) 
    {
        die("Connection failed: " . mysqli_connect_error());
    }
    
    $lbl=$_POST["btn"];
    echo "<h1> " . $lbl . "</h1>";
//---------------------------------------------------------------------------------------------------
    if($lbl=="add")
    {
            //echo "record inserted <br>";
        if(!empty($_POST['name']) && isset($_POST['contact'])  && isset($_POST['pwdd'])  && isset($_POST['email'])  && isset($_POST['date'])  && isset($_POST['Branch'])  && isset($_POST['Year'])  && isset($_POST['add']))
        {

            $name=$_POST['name'];
            $contact=$_POST['contact'];
            $pwdd=$_POST['pwdd'];
            $email=$_POST['email'];
            $date=$_POST['date'];
            $age=$_POST['age'];
            $Branch=$_POST['Branch'];
            $Year=$_POST['Year'];
            $add=$_POST['add'];


			$sql = "INSERT INTO register (Name, Contact_no, Password, Email_id, Date_Of_birth, Age, Branch_name, Year_name, Address) VALUES ('$name', '$contact', '$pwdd', '$email', '$date', '$date', '$Branch', '$Year', '$add')";
			
		
            if (mysqli_query($conn, $sql)) 
            {
                // echo "New record created successfully";
                header( "Location: alumina.php" );

            } 
            else
            {
                echo "Error: " . $sql . "<br>" . mysqli_error($conn);

            } 
        }
        else
        {
            echo "enter the information" ;
        }
        mysqli_close($conn);
    } 
}
     ?>


</body>
</html>

       