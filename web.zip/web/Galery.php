<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>
<div class="row" style="background-color: rgb(134, 188, 204)">
        <p><h1 style="text-align-last: center">MGM POLYTECHNIC COLLAGE</h1></p>
    </div>
    <div class="row">
        <nav class="navbar navbar-inverse">
          <div class="container-fluid">
            </ul>
            <ul class="nav navbar-nav" >
                <li class="active"><a href="#">Anumilla website</a></li>
                 </ul>
            <ul class="nav navbar-nav" >
            <li class="active"><a href="index.php">Home</a></li>
             </ul>
             <ul class="nav navbar-nav" >
                <li class="dropdown active"><a class="dropdown-toggle" data-toggle="dropdown" href="#">About us<span class="caret"></span></a>                 <ul class="dropdown-menu">
                   
                      <li><a href="info.php">Information</a></li>
                      <li><a href="intec.php">Intake</a></li>
                      <li><a href="contact.php">Contact us</a></li>
                      </ul></li>  </ul>
                      <ul class="nav navbar-nav" >
                          <li class="active"><a href="event.php">Events</a></li>
                         </ul>
                            <ul class="nav navbar-nav" >
                            <li class="active"><a href="Galery.php">Gallery</a></li>
                           </ul>  
                           <ul class="nav navbar-nav navbar-right" >
                              <li class="active"><a href="sign.php">Signup</a></li>
                             </ul>            
                             <ul class="nav navbar-nav navbar-right" >
                             <li class="dropdown active"><a class="dropdown-toggle" data-toggle="dropdown" href="#">login<span class="caret"></span></a>                
                              <ul class="dropdown-menu">
                              <li><a href="log.php">USER</a></li>
                      <li><a href="admin.php">ADMIN</a></li>
 
                               </ul></div>
    </nav>
    </div>
    
 
 <div id="myCarousel" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="1"></li>
    <li data-target="#myCarousel" data-slide-to="2"></li>
    <li data-target="#myCarousel" data-slide-to="3"></li>
    <li data-target="#myCarousel" data-slide-to="4"></li>
    <li data-target="#myCarousel" data-slide-to="5"></li>
    <li data-target="#myCarousel" data-slide-to="6"></li>
    <li data-target="#myCarousel" data-slide-to="7"></li>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner">
    <div class="item active">
      <img src="mp.jpg" style="width=100" >
    </div>

    <div class="item">
      <img src="tn2.jpg" style="width=100" >
    </div>

    <div class="item">
      <img src="pt.jpg" style="width=100">
    </div>
    
   <!-- <div class="item"></div>-->
     
     <div class="item">
      <img src="tn1.jpg" style="width=100">
    </div>
    
    <div class="item">
      <img src="you.jpg" style="width=100">
    </div>
    
    <div class="item">
      <img src="you1.jpg" style="width=100">
    </div>
    <div class="item">
      <img src="pp.jpg" style="width=100">
    </div>
  </div>
  

  <!-- Left and right controls -->
  <a class="left carousel-control" href="#myCarousel" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#myCarousel" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
</body>
</html>