<html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<?php
 session_start();
 if(isset($_POST['btn']))
 {

/*$servername = "localhost";
$username = "root";
$password = "";
$dbname = "alu";*/
$servername = "localhost";
  $username = "id10482724_tejal";
  $password = "90115854";
  
  $dbname = "id10482724_alu";


// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) 
{
    die("Connection failed: " . mysqli_connect_error());
}
else{
    echo "connected";
}
$lbl=$_POST["btn"];
echo "<h1> " . $lbl . "</h1>";
if($lbl=="Insert")
{
    echo "record inserted <br>";
    if(!empty($_POST['name']) && isset($_POST['contact'])  && isset($_POST['email']) && isset($_POST['age']) && isset($_POST['Branch'])  && isset($_POST['Year'])  && isset($_POST['Result'])  && isset($_POST['add']))
    {
    $name=$_POST['name'];
    $contact=$_POST['contact'];
    $email=$_POST['email'];
    $age=$_POST['age'];
    $Branch=$_POST['Branch'];
    $Year=$_POST['Year'];
    $Result=$_POST['Result'];
    $add=$_POST['add'];

    
    $sql = "INSERT INTO enquiry (Name, Contact_no, Email_id, Age, Branch, Year_name, Result, Address)
    VALUES ('$name', '$contact', '$email', '$age', '$Branch', '$Year', '$Result', '$add')";
    if (mysqli_query($conn, $sql)) {
        echo "New record created successfully";
    } 
    else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
}
else{
    echo "enter the information" ;
}
mysqli_close($conn);
 }
 else if($lbl=="Update")
{
    echo " record updated <br>";
    if(!empty($_POST['name']) && isset($_POST['contact'])  && isset($_POST['email']) && isset($_POST['age']) && isset($_POST['Branch'])  && isset($_POST['Year'])  && isset($_POST['Result'])  && isset($_POST['add']))
   
    {
        $name=$_POST['name'];
        $contact=$_POST['contact'];
        $email=$_POST['email'];
        $age=$_POST['age'];
        $Branch=$_POST['Branch'];
        $Year=$_POST['Year'];
        $Result=$_POST['Result'];
        $add=$_POST['add'];
    
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    
    $sql = "UPDATE enquiry SET Name='$name', Contact_no='$contact', Age='$age', Branch='$Branch', Year_name='$Year', Result='$Result', Address='$add' WHERE Email_id='$email'";
    
    if (mysqli_query($conn, $sql)) {
        echo "Record updated successfully";
    } 
    else {
        echo "Error updating record: " . mysqli_error($conn);
    }
}
else{
    echo "enter detail";
}
    
}
//------------------------------------------
else if($lbl=="Show")
{
    echo " show record <br>";
    if(isset($_POST['btn']))
   // if(!empty($_POST['name']) && isset($_POST['contact'])  && isset($_POST['email']) && isset($_POST['age']) && isset($_POST['Branch'])  && isset($_POST['Year'])  && isset($_POST['Result'])  && isset($_POST['add']))
   
    {
    $sql = "SELECT * FROM enquiry";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    $_SESSION["uniqueid"] = $email;
     // $_SESSION["password"] = $pwd;
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        echo "name: " . $row["Name"]. "<br> contact:" . $row["Contact_no"]. "<br> email:" . $row["Email_id"]. "<br> age:" . $row["Age"]. "<br> Branch: " . $row["Branch"]. "<br> Year: " . $row["Year_name"]. "<br> Result: " . $row["Result"]. "<br> add: " . $row["Address"]. "<br>" ;

    }
} else {
    echo "0 results";
}
}
else 
{
    echo "enter deatail";
}
}
//------------------------------------------------
else if($lbl=="Delete")
{
    echo " record Deleted <br>";
    if(isset($_POST['email']))
    {
    $email=$_POST['email'];
    $sql = "DELETE FROM enquiry WHERE Email_id='$email'";

if (mysqli_query($conn, $sql)) {
    echo "Record deleted successfully";
} else {
    echo "Error deleting record: " . mysqli_error($conn);
}
}
else
{
    echo "enter detail";
}
}
else if($lbl=="Search")
{
    echo " record Searched <br>";
    if(!empty($_POST['email']))
    {
    $email=$_POST['email'];
    $sql = "SELECT * FROM enquiry WHERE Email_id='$email'";
$result = mysqli_query($conn, $sql);

            if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        echo "name: " . $row["Name"]. "<br> contact:" . $row["Contact_no"]. "<br> email:" . $row["Email_id"]. "<br> age:" . $row["Age"]. "<br> Branch: " . $row["Branch"]. "<br> Year: " . $row["Year_name"]. "<br> Result: " . $row["Result"]. "<br> add: " . $row["Address"]. "<br>" ;

    }
}

        
else {
    echo "0 results";
}}
else{
    echo "enter details" ;
}

 }
 }
?>

</body>
</html>