<!DOCTYPE html>
<html lang="en">
<head>
  <title>Allumina website</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>
<div class="row" style="background-color: rgb(134, 188, 204)">
                <p><h1 style="text-align-last: center">MGM POLYTECHNIC COLLAGE</h1></p>
            </div>
            

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header, active">
      <a class="navbar-brand" href="#"> Allumina WebSite</a>
    </div>
    <ul class="nav navbar-nav">
    <li class="active"><a href="profilead.php">Profile</a></li>
      <li class="active"><a href="alumina.php">ALLUMINA</a></li>
          </ul>
    <form class="navbar-form navbar-right"> 
    <ul class="nav navbar-nav">
    <li class="active"><a href="adminlogout.php"><span class="glyphicon glyphicon-log-in">logout</span></a></li>

     <!-- <li class="active"><a href="#">logout</a></li>-->
      <!--<li><a href="#">Page 1</a></li>
      <li><a href="#">Page 2</a></li>-->
    </ul></form>
    <!--<form class="navbar-form navbar-right">
      <div class="input-group">
        <input type="text" class="form-control" placeholder="Search" name="search">
        <div class="input-group-btn">
          <button class="btn btn-default" type="submit">
            <i class="glyphicon glyphicon-search"></i>
          </button>
        </div>
      </div>
    </form>-->
  </div>
  
</nav>

<div class="container">
  <h3 style="text-align-last: center">WELCOME!!!</h3>
  <p style="text-align-last: center">YOU ARE SUCCESFULLY LOGIN HERE!!</p>
  </div>

</body>
</html>

