<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>
    <div class="row" style="background-color: rgb(134, 188, 204)">
        <p><h1 style="text-align-last: center">MGM POLYTECHNIC COLLAGE</h1></p>
    </div>
    <div class="row">
        <nav class="navbar navbar-inverse">
          <div class="container-fluid">
            </ul>
            <ul class="nav navbar-nav" >
                <li class="active"><a href="#">Anumilla website</a></li>
                 </ul>
            <ul class="nav navbar-nav" >
            <li class="active"><a href="index.php">Home</a></li>
             </ul>
             <ul class="nav navbar-nav" >
                <li class="dropdown active"><a class="dropdown-toggle" data-toggle="dropdown" href="#">About us<span class="caret"></span></a>                 <ul class="dropdown-menu">
                   
                      <li><a href="info.php">Information</a></li>
                      <li><a href="intec.php">Intake</a></li>
                      <li><a href="contact.php">Contact us</a></li>
                      </ul></li>  </ul>
                      <ul class="nav navbar-nav" >
                          <li class="active"><a href="event.php">Events</a></li>
                         </ul>
                            <ul class="nav navbar-nav" >
                            <li class="active"><a href="Galery.php">Gallery</a></li>
                           </ul>  
                           <ul class="nav navbar-nav navbar-right" >
                              <li class="active"><a href="sign.php">Signup</a></li>
                             </ul>            
                             <ul class="nav navbar-nav navbar-right" >
                             <li class="dropdown active"><a class="dropdown-toggle" data-toggle="dropdown" href="#">login<span class="caret"></span></a>                
                              <ul class="dropdown-menu">
                              <li><a href="log.php">USER</a></li>
                      <li><a href="admin.php">ADMIN</a></li>
 
                               </ul></div>
    </nav>
    </div>
                
  <div class="row" style="text-align-last: center; background-color: gray" >          
      <div class="col-sm-4" ><img src="p1.jpg" width="220" height="300">
           <h2>Come for a visit</h2>
            <p>Take a campus tour, indusrial visit and learn what its like to be a waterloo student</p>                            
             </div>
            <div class="col-sm-4" style="text-align-last: center"><img src="tn.jpg" width="220" height="300">
            <h2>practical knowlegde</h2>
            <p>We are giving a more practical knowlege instead of theory knowlegde. and make student technically strong</p>
          </div>
          <div class="col-sm-4" style="text-align-last: center"><img src="s1.jpg" width="220" height="300">
            <h2>PLACEMENTS</h2>        
            <p>Here provide placements for students throgh interview and apti test </p>                         
               </div>
                </div>
              </div>
              
    
</body>
</html>
