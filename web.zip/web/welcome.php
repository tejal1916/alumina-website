
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Allumina website</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>
<div class="row" style="background-color: rgb(134, 188, 204)">
                <p><h1 style="text-align-last: center">MGM POLYTECHNIC COLLAGE</h1></p>
            </div>
            

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header, active">
      <a class="navbar-brand" href="#"> Allumina WebSite</a>
    </div>
    <ul class="nav navbar-nav">
    <li class="active"><a href="profile.php"><span class="glyphicon glyphicon-user">Profile</span></a></li>
      <!--<li><a href="#">Page 1</a></li>
      <li><a href="#">Page 2</a></li>-->
    </ul>
    <ul class="nav navbar-nav" >
            <li class="active"><a href="enquiry2.php">Student details</a></li>
             </ul>
             <ul class="nav navbar-nav" >
            <li class="active"><a href="companydetail.php">Comapany details</a></li>
             </ul>
    <form class="navbar-form navbar-right"> 
    <ul class="nav navbar-nav">
    <li class="active"><a href="logoutuser.php"><span class="glyphicon glyphicon-log-in">logout</span></a></li>

     <!-- <li class="active"><a href="#">logout</a></li>-->
      <!--<li><a href="#">Page 1</a></li>
      <li><a href="#">Page 2</a></li>-->
    </ul></form>

  </div>
  
</nav>
<div class="row" style="background-color:rgb(206,208,211)">
<div class="col-sm-4" >
</div>
<div class="col-sm-4" >


  <h3 style="text-align-last: center">WELCOME!!!</h3>
  <p style="text-align-last: center">YOU ARE SUCCESFULLY LOGIN HERE!!</p>
  
  <img src="shake.jpg" width="220" height="300">
  </div>
  
  <div class="col-sm-4" >
  </div>
  </div>
</div>
</body>
</html>

