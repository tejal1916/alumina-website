<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<div class="row" style="background-color: rgb(134, 188, 204)">
                <p><h1 style="text-align-last: center">MGM POLYTECHNIC COLLAGE</h1></p>
            </div>
            

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header, active">
      <a class="navbar-brand" href="#"> Allumina WebSite</a>
    </div>
    <ul class="nav navbar-nav">
    <li class="active"><a href="profilead.php">Profile</a></li>
      <li class="active"><a href="alumina.php">ALLUMINA</a></li>
          </ul>
    <form class="navbar-form navbar-right"> 
    <ul class="nav navbar-nav">
    <li class="active"><a href="adminlogout.php"><span class="glyphicon glyphicon-log-in">logout</span></a></li>

     <!-- <li class="active"><a href="#">logout</a></li>-->
      <!--<li><a href="#">Page 1</a></li>
      <li><a href="#">Page 2</a></li>-->
    </ul></form>
    <!--<form class="navbar-form navbar-right">
      <div class="input-group">
        <input type="text" class="form-control" placeholder="Search" name="search">
        <div class="input-group-btn">
          <button class="btn btn-default" type="submit">
            <i class="glyphicon glyphicon-search"></i>
          </button>
        </div>
      </div>
    </form>-->
  </div>
  
</nav>

       
<button type="submit" class="btn btn-default" name="btn" value="add"><a href="aluminaadd.php">Add</a></button>


<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "alu";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) 
{
    die("Connection failed: " . mysqli_connect_error());
}
else{
    //echo "connected";
}

$sql = "select * from register";
			
		$result = mysqli_query($conn, $sql);
?>
    <div class="row" style="background-color:rgb(206,208,211)">

<div class="row" style="text-align: center; table table-striped">

    	<div class="col-sm-1"><label>NAME</label></div>
        	<div class="col-sm-1"><label>CONTACT</label></div>
            	<div class="col-sm-1"><label>PASSWORD</label></div>
                <div class="col-sm-1"><label>EMAIL</label></div>
                <div class="col-sm-2"><label>D_O_B</label></div>
                <div class="col-sm-1"><label>AGE</label></div>
                <div class="col-sm-1"><label>BRANCH</label></div>
                <div class="col-sm-1"><label>YEAR</label></div>
                <div class="col-sm-1"><label>ADDRESS</label></div>
                <div class="col-sm-1"><label>Edit</label></div>
                <div class="col-sm-1"><label>Delete</label></div>
                				
                			
</div>


<?php
if (mysqli_num_rows($result) > 0) 
{
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) 
    {
		
?>
				<div class="row" style="text-align: center; table table-striped">
					<div class="col-sm-1"><label><?php echo $row["Name"]; ?></label></div>
			    	<div class="col-sm-1"><label><?php echo $row["Contact_no"]; ?></label></div>
        			<div class="col-sm-1"><label><?php echo $row["Password"]; ?></label></div>
                    <div class="col-sm-1"><label><?php echo $row["Email_id"]; ?></label></div>
                    <div class="col-sm-2"><label><?php echo $row["Date_of_birth"]; ?></label></div>
                    <div class="col-sm-1"><label><?php echo $row["Age"]; ?></label></div>
                    <div class="col-sm-1"><label><?php echo $row["Branch_name"]; ?></label></div>
                    <div class="col-sm-1"><label><?php echo $row["Year_name"]; ?></label></div>
                    <div class="col-sm-1"><label><?php echo $row["Address"]; ?></label></div>
                    <div class="col-sm-1" style="text-align: center">
                     <button type="submit" class="btn btn-default" name="btn" value="edit"><a href="edit.php?name=<?php echo $row["Name"];?>&contact=<?php echo $row["Contact_no"];?>&pwdd=<?php echo $row["Password"];?>&email=<?php echo $row["Email_id"];?>&date=<?php echo $row["Date_of_birth"];?>&age=<?php echo $row["Age"];?>&Branch=<?php echo $row["Branch_name"];?>&Year=<?php echo $row["Year_name"];?>&add=<?php echo $row["Address"];?>">Edit</a></button>                
                        </div>
                     <div class="col-sm-1" style="text-align: center">
                     <button type="submit" class="btn btn-default" name="btn" value="delete"><a href="delete.php?email=<?php echo $row["Email_id"]; ?>">Delete</a></button>
                     </div>
            	</div>	
<?php
    }
} 
else 
{
    echo '<div class="row">';
    echo '<div class="col-sm-12"><h2>results</h2></div>';
	echo '</div>';
}
		
		mysqli_close($conn);
?>
</div>
</div>
</body>
</html>