
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Allumina website</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>
<div class="row" style="background-color: rgb(134, 188, 204)">
                <p><h1 style="text-align-last: center">MGM POLYTECHNIC COLLAGE</h1></p>
            </div>
            

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header, active">
      <a class="navbar-brand" href="#"> Allumina WebSite</a>
    </div>
    
    <ul class="nav navbar-nav" >
            <li class="active"><a href="enquiry2.php">Student details</a></li>
             </ul>
             <ul class="nav navbar-nav" >
            <li class="active"><a href="#">Comapany details</a></li>
             </ul>
             <ul class="nav navbar-nav">
    <li class="active"><a href="profile.php"><span class="glyphicon glyphicon-user">Profile</span></a></li>
      </ul>
    <form class="navbar-form navbar-right"> 
    <ul class="nav navbar-nav">
    <li class="active"><a href="logoutuser.php"><span class="glyphicon glyphicon-log-in">logout</span></a></li>

    </ul></form>
    
  </div>
  
</nav>



<?php  
  session_start();
  $email=$_SESSION["uniqueid"];
  //$pwd=$_SESSION["password"];
		
		
				
		/*$servername = "localhost";
		$username = "root";
		$password = "";
		
    $dbname = "alu";*/
    $servername = "localhost";
  $username = "id10482724_tejal";
  $password = "90115854";
  
  $dbname = "id10482724_alu";
/
		
		
		
		
		$conn = mysqli_connect($servername, $username, $password,$dbname);
		
		// Check connection
		
		
		
    if (!$conn) 
    {
			die("Connection failed: " . mysqli_connect_error());
		}
		//echo "Connected successfully";
		
    $sql = "SELECT * FROM enquiry WHERE Email_id='$email'";
			$result=mysqli_query($conn, $sql);
			if (mysqli_num_rows($result) > 0) 
			{
		
         while($row = $result->fetch_assoc())
          {
			
//        echo "<b><i><br> Email_address: </i></b>". $row["Email_address"]. "<b><i><br>Password: </i></b>". $row["Password"]. "<b><i><br>Name:</i></b>" . $row["Name"] . "<b><i><br>Address:</i></b> ". $row["Address"]. "<b><i><br>Contact_no: </i></b>". $row["Contact_no"]. "<br>";
			
			echo '<div class="row">';
			echo '<div class="col-sm-6"><label>Name :</label></div><div class="col-sm-6"><label>'.$row["Name"].'</label></div>';
			echo '</div>';
			
			echo '<div class="row">';
			echo '<div class="col-sm-6"><label>Email Address :</label></div><div class="col-sm-6"><label>'.$row["Contact_no"].'</label></div>';
			echo '</div>';
			
			echo '<div class="row">';
			echo '<div class="col-sm-6"><label>Address :</label></div><div class="col-sm-6"><label>'.$row["Address"].'</label></div>';
			echo '</div>';
			
			echo '<div class="row">';
			echo '<div class="col-sm-6"><label>Date_of_birth :</label></div><div class="col-sm-6"><label>'.$row["Year_name"].'</label></div>';
      echo '</div>';

      echo '<div class="row">';
			echo '<div class="col-sm-6"><label>Age :</label></div><div class="col-sm-6"><label>'.$row["Age"].'</label></div>';
      echo '</div>';

      echo '<div class="row">';
      echo '<div class="col-sm-6"><label>Branch_name :</label></div><div class="col-sm-6"><label>'.$row["Branch"].'</label></div>';
			echo '</div>';
				
     // echo '<div class="row">';
		//	echo '<div class="col-sm-6"><label>Year_name :</label></div><div class="col-sm-6"><label>'.$row["Year_name"].'</label></div>';
			//echo '</div>';
				
				 }
      } else
       {
				$message = "please register your name";
			
				?>
                
				<!--<script type="text/javascript">alert("wrong emailid or password...please login with valid email and password");</script>
         -->       <?php
			//	header( "Location: log.php" );
				
			}
		mysqli_close($conn);		

?>




  </div>

</body>
</html>

