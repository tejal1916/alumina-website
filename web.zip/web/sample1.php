<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>

<body>

<?php
$link=mysqli_connect("localhost","root","");
mysqli_select_db($link,"image");
?>
<div class="row"style="text-align:center"> 
    <form name="forml" action="" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="pname">Product Image:</label>
            <input type="file" class="form-control" id="pimage" placeholder="Enter Product Name" name="pimage">
        </div>
    <button type="submit" class="btn btn-default" name="submit1" value="upload">show image</button>
  </form>
 
</div>

<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "alu";
		
$conn = mysqli_connect($servername, $username, $password,$dbname);
		
if (!$conn) 
{
	die("Connection failed: " . mysqli_connect_error());
}

if(isset($_POST["submit1"]))
{
	$fnm=$_FILES["pimage"]["name"];
	$dst="./uploads/".$fnm;
	$dst1="./uploads/".$fnm;

	move_uploaded_file($_FILES["pimage"]["tmp_name"],$dst); 
	
$sql = "INSERT INTO register (image) VALUES ('$dst1')";
			
    if (mysqli_query($conn, $sql)) 
    {
        //echo "New record created successfully";
		//header( "Location: userlogin.php" );
    } 
    else 
    {
		echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
    
mysqli_close($conn);		
}
?>  

<?php
$sql = "select * from register";
			
		$result = mysqli_query($conn, $sql,);

if (mysqli_num_rows($result) > 0) 
{
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) 
    {
		
?>
	    <div class="row">
            <div class="col-sm-3"></div>
            
			<div class="col-sm-6"><img src=<?php echo $row["image"]; ?> height="100px" width="200px"></div>
            <div class="col-sm-3"></div>
        </div>
		
<?php
    }
} 
else 
{
	echo '<div class="row">';
    echo '<div class=col-sm-12><h2>0 results</h2></div>';
	echo '</div>';
}
		
	
		
		

?>    


</body>
</html>